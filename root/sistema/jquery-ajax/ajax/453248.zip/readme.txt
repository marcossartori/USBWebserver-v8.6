******************************************************
Thank you for using our CSS Layout Generator.

This zip file contains the following files:

- 1 * HTM file located in the html directory
- 2 * CSS files located in the css directory
- 1 * TXT file

To change any of the settings, just open up the files
in your favourite web editor.

If you use one of these layouts, please consider 
linking to CSS Portal at the following:

http://www.cssportal.com

******************************************************